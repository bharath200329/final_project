from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import hashlib
import os
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Database initialization
def init_db():
    # Create data directory if it doesn't exist
    if not os.path.exists('data'):
        os.makedirs('data')
    
    conn = sqlite3.connect('data/lms.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL,
        full_name TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
    )''')
    
    # Courses table
    c.execute('''CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        instructor_id INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (instructor_id) REFERENCES users(id)
    )''')
    
    # Course materials table
    c.execute('''CREATE TABLE IF NOT EXISTS course_materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        content TEXT,
        file_path TEXT,
        material_type TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Enrollments table
    c.execute('''CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        course_id INTEGER,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Assessments table
    c.execute('''CREATE TABLE IF NOT EXISTS assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        total_marks INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Questions table
    c.execute('''CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assessment_id INTEGER,
        question_text TEXT NOT NULL,
        option_a TEXT,
        option_b TEXT,
        option_c TEXT,
        option_d TEXT,
        correct_answer TEXT,
        marks INTEGER DEFAULT 1,
        FOREIGN KEY (assessment_id) REFERENCES assessments(id)
    )''')
    
    # Results table
    c.execute('''CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        assessment_id INTEGER,
        score INTEGER,
        total_marks INTEGER,
        percentage REAL,
        feedback TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (assessment_id) REFERENCES assessments(id)
    )''')
    
    # Assignments table
    c.execute('''CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        due_date DATE,
        total_marks INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Assignment submissions table
    c.execute('''CREATE TABLE IF NOT EXISTS assignment_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER,
        student_id INTEGER,
        submission_text TEXT,
        file_path TEXT,
        score INTEGER,
        feedback TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (assignment_id) REFERENCES assignments(id),
        FOREIGN KEY (student_id) REFERENCES users(id)
    )''')

    # Course requests table (student-driven)
    c.execute('''CREATE TABLE IF NOT EXISTS course_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        requested_by INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (requested_by) REFERENCES users(id)
    )''')

    # Course request votes (support by students)
    c.execute('''CREATE TABLE IF NOT EXISTS course_request_votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_id INTEGER,
        student_id INTEGER,
        voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(request_id, student_id),
        FOREIGN KEY (request_id) REFERENCES course_requests(id),
        FOREIGN KEY (student_id) REFERENCES users(id)
    )''')

    # Instructor interests in course requests
    c.execute('''CREATE TABLE IF NOT EXISTS instructor_interests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        instructor_id INTEGER,
        request_id INTEGER,
        selected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(instructor_id, request_id),
        FOREIGN KEY (instructor_id) REFERENCES users(id),
        FOREIGN KEY (request_id) REFERENCES course_requests(id)
    )''')

    # Academic calendar entries
    c.execute('''CREATE TABLE IF NOT EXISTS academic_calendar (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        start_date DATE,
        end_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')

    # Attendance sessions
    c.execute('''CREATE TABLE IF NOT EXISTS attendance_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        session_date DATE NOT NULL,
        topic TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')

    # Attendance records
    c.execute('''CREATE TABLE IF NOT EXISTS attendance_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER,
        student_id INTEGER,
        status TEXT NOT NULL,
        marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(session_id, student_id),
        FOREIGN KEY (session_id) REFERENCES attendance_sessions(id),
        FOREIGN KEY (student_id) REFERENCES users(id)
    )''')

    # Course categories
    c.execute('''CREATE TABLE IF NOT EXISTS course_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Course category mapping
    c.execute('''CREATE TABLE IF NOT EXISTS course_category_mapping (
        course_id INTEGER,
        category_id INTEGER,
        PRIMARY KEY (course_id, category_id),
        FOREIGN KEY (course_id) REFERENCES courses(id),
        FOREIGN KEY (category_id) REFERENCES course_categories(id)
    )''')

    # Announcements
    c.execute('''CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_by INTEGER,
        is_global INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )''')

    # Discussion forums
    c.execute('''CREATE TABLE IF NOT EXISTS forum_threads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        content TEXT,
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )''')

    # Forum replies
    c.execute('''CREATE TABLE IF NOT EXISTS forum_replies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        thread_id INTEGER,
        content TEXT NOT NULL,
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (thread_id) REFERENCES forum_threads(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )''')

    # Notifications
    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT NOT NULL,
        message TEXT,
        link TEXT,
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    # Course ratings and reviews
    c.execute('''CREATE TABLE IF NOT EXISTS course_reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        student_id INTEGER,
        rating INTEGER CHECK(rating >= 1 AND rating <= 5),
        review TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(course_id, student_id),
        FOREIGN KEY (course_id) REFERENCES courses(id),
        FOREIGN KEY (student_id) REFERENCES users(id)
    )''')

    # Certificates
    c.execute('''CREATE TABLE IF NOT EXISTS certificates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        course_id INTEGER,
        certificate_code TEXT UNIQUE NOT NULL,
        issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')

    # Progress tracking
    c.execute('''CREATE TABLE IF NOT EXISTS student_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        course_id INTEGER,
        material_id INTEGER,
        completed INTEGER DEFAULT 0,
        completed_at TIMESTAMP,
        UNIQUE(student_id, course_id, material_id),
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (course_id) REFERENCES courses(id),
        FOREIGN KEY (material_id) REFERENCES course_materials(id)
    )''')

    # Messages
    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        subject TEXT,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id),
        FOREIGN KEY (receiver_id) REFERENCES users(id)
    )''')

    # User profiles
    c.execute('''CREATE TABLE IF NOT EXISTS user_profiles (
        user_id INTEGER PRIMARY KEY,
        bio TEXT,
        phone TEXT,
        address TEXT,
        profile_picture TEXT,
        social_links TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    # Badges/Achievements
    c.execute('''CREATE TABLE IF NOT EXISTS badges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        icon TEXT,
        criteria TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # User badges
    c.execute('''CREATE TABLE IF NOT EXISTS user_badges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        badge_id INTEGER,
        earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (badge_id) REFERENCES badges(id)
    )''')

    # Live sessions
    c.execute('''CREATE TABLE IF NOT EXISTS live_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        meeting_link TEXT,
        scheduled_at TIMESTAMP,
        duration_minutes INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')

    # Insert default badges
    default_badges = [
        ('First Steps', 'Enrolled in your first course', '🎓', 'enroll_first_course'),
        ('Assessment Master', 'Scored 100% in an assessment', '🏆', 'perfect_score'),
        ('Active Learner', 'Completed 5 courses', '📚', 'complete_5_courses'),
        ('Discussion Leader', 'Created 10 forum threads', '💬', 'create_10_threads'),
        ('Perfect Attendance', 'Perfect attendance for 1 month', '✅', 'perfect_attendance')
    ]
    for badge in default_badges:
        try:
            c.execute('INSERT INTO badges (name, description, icon, criteria) VALUES (?, ?, ?, ?)', badge)
        except sqlite3.IntegrityError:
            pass

    # Insert default course categories
    default_categories = [
        ('Computer Science', 'Programming, algorithms, and software development'),
        ('Mathematics', 'Pure and applied mathematics courses'),
        ('Business', 'Business administration, management, and finance'),
        ('Science', 'Natural sciences including physics, chemistry, biology'),
        ('Arts & Humanities', 'Literature, history, philosophy, and arts'),
        ('Engineering', 'Various engineering disciplines'),
        ('Languages', 'Foreign language learning'),
        ('Health & Medicine', 'Medical and health-related courses')
    ]
    for category in default_categories:
        try:
            c.execute('INSERT INTO course_categories (name, description) VALUES (?, ?)', category)
        except sqlite3.IntegrityError:
            pass
    
    # Create default admin user
    try:
        password_hash = hashlib.sha256('admin123'.encode()).hexdigest()
        c.execute('''INSERT INTO users (username, password, email, role, full_name) 
                     VALUES (?, ?, ?, ?, ?)''',
                  ('admin', password_hash, 'admin@lms.com', 'admin', 'System Administrator'))
    except sqlite3.IntegrityError:
        pass  # Admin already exists
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Database helper functions
def get_db():
    conn = sqlite3.connect('data/lms.db', timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # Enable WAL mode for better concurrent access
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=30000')
    return conn

# Helper function to create notifications
def create_notification(conn, user_id, title, message, link=None):
    """Create a notification using the provided connection object"""
    conn.execute('''INSERT INTO notifications (user_id, title, message, link)
                    VALUES (?, ?, ?, ?)''', (user_id, title, message, link))

# Helper function to award badges
def check_and_award_badges(user_id):
    conn = get_db()
    
    # Check for first enrollment badge
    enrollments = conn.execute('SELECT COUNT(*) as count FROM enrollments WHERE student_id = ?', (user_id,)).fetchone()['count']
    if enrollments == 1:
        badge_id = conn.execute('SELECT id FROM badges WHERE criteria = ?', ('enroll_first_course',)).fetchone()
        if badge_id:
            try:
                conn.execute('INSERT INTO user_badges (user_id, badge_id) VALUES (?, ?)', (user_id, badge_id['id']))
                conn.commit()
            except sqlite3.IntegrityError:
                pass
    
    conn.close()

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Role required decorator
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] != role:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Routes

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                           (username, password_hash)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['full_name'] = user['full_name']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    conn = get_db()
    course_requests = conn.execute('''
        SELECT cr.*, COUNT(crv.id) as votes
        FROM course_requests cr
        LEFT JOIN course_request_votes crv ON cr.id = crv.request_id
        WHERE cr.status = 'pending'
        GROUP BY cr.id
        ORDER BY votes DESC, cr.created_at DESC
    ''').fetchall()

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        full_name = request.form['full_name']
        role = request.form.get('role', 'student')
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        try:
            conn.execute('''INSERT INTO users (username, password, email, role, full_name) 
                           VALUES (?, ?, ?, ?, ?)''',
                        (username, password_hash, email, role, full_name))
            user_id = conn.execute('SELECT id FROM users WHERE username = ?', (username,)).fetchone()['id']

            if role == 'instructor':
                selected_requests = request.form.getlist('course_interest_ids')
                for request_id in selected_requests:
                    try:
                        conn.execute('''INSERT INTO instructor_interests (instructor_id, request_id)
                                       VALUES (?, ?)''', (user_id, request_id))
                    except sqlite3.IntegrityError:
                        pass

            conn.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists', 'danger')
        finally:
            conn.close()
    else:
        conn.close()

    return render_template('register.html', course_requests=course_requests)

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    
    if role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'instructor':
        return redirect(url_for('instructor_dashboard'))
    else:
        return redirect(url_for('student_dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# ========== ADMIN MODULE ==========

@app.route('/admin/dashboard')
@login_required
@role_required('admin')
def admin_dashboard():
    conn = get_db()
    
    # Get statistics
    total_users = conn.execute('SELECT COUNT(*) as count FROM users').fetchone()['count']
    total_students = conn.execute('SELECT COUNT(*) as count FROM users WHERE role = "student"').fetchone()['count']
    total_instructors = conn.execute('SELECT COUNT(*) as count FROM users WHERE role = "instructor"').fetchone()['count']
    total_courses = conn.execute('SELECT COUNT(*) as count FROM courses').fetchone()['count']
    pending_courses = conn.execute('SELECT COUNT(*) as count FROM courses WHERE status = "pending"').fetchone()['count']
    
    # Get recent users
    recent_users = conn.execute('SELECT * FROM users ORDER BY created_at DESC LIMIT 5').fetchall()
    
    # Get pending courses
    pending_courses_list = conn.execute('''
        SELECT c.*, u.full_name as instructor_name 
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.status = "pending"
        ORDER BY c.created_at DESC
    ''').fetchall()

    # Course requests eligible for faculty assignment (>= 4 votes)
    eligible_requests = conn.execute('''
        SELECT cr.*, COUNT(crv.id) as votes
        FROM course_requests cr
        LEFT JOIN course_request_votes crv ON cr.id = crv.request_id
        WHERE cr.status = 'pending'
        GROUP BY cr.id
        HAVING votes >= 4
        ORDER BY votes DESC, cr.created_at DESC
    ''').fetchall()

    instructors = conn.execute('''
        SELECT id, full_name, email
        FROM users
        WHERE role = 'instructor' AND status = 'active'
        ORDER BY full_name ASC
    ''').fetchall()

    eligible_request_interests = {}
    for req in eligible_requests:
        interests = conn.execute('''
            SELECT u.id, u.full_name
            FROM instructor_interests i
            JOIN users u ON i.instructor_id = u.id
            WHERE i.request_id = ?
            ORDER BY u.full_name ASC
        ''', (req['id'],)).fetchall()
        eligible_request_interests[req['id']] = interests
    
    conn.close()
    
    return render_template('admin_dashboard.html',
                         total_users=total_users,
                         total_students=total_students,
                         total_instructors=total_instructors,
                         total_courses=total_courses,
                         pending_courses=pending_courses,
                         recent_users=recent_users,
                         pending_courses_list=pending_courses_list,
                         eligible_requests=eligible_requests,
                         instructors=instructors,
                         eligible_request_interests=eligible_request_interests)

@app.route('/admin/users')
@login_required
@role_required('admin')
def admin_users():
    conn = get_db()
    users = conn.execute('SELECT * FROM users ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin_users.html', users=users)

@app.route('/admin/approve_course/<int:course_id>')
@login_required
@role_required('admin')
def approve_course(course_id):
    conn = get_db()
    conn.execute('UPDATE courses SET status = "approved" WHERE id = ?', (course_id,))
    conn.commit()
    conn.close()
    flash('Course approved successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reject_course/<int:course_id>')
@login_required
@role_required('admin')
def reject_course(course_id):
    conn = get_db()
    conn.execute('UPDATE courses SET status = "rejected" WHERE id = ?', (course_id,))
    conn.commit()
    conn.close()
    flash('Course rejected.', 'info')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/analytics')
@login_required
@role_required('admin')
def admin_analytics():
    conn = get_db()
    
    # Get various analytics data
    enrollment_data = conn.execute('''
        SELECT c.title, COUNT(e.id) as count
        FROM courses c
        LEFT JOIN enrollments e ON c.id = e.course_id
        WHERE c.status = "approved"
        GROUP BY c.id
        ORDER BY count DESC
        LIMIT 10
    ''').fetchall()
    
    # Get performance data
    performance_data = conn.execute('''
        SELECT u.full_name, AVG(r.percentage) as avg_percentage
        FROM users u
        JOIN results r ON u.id = r.student_id
        WHERE u.role = "student"
        GROUP BY u.id
        ORDER BY avg_percentage DESC
        LIMIT 10
    ''').fetchall()
    
    conn.close()
    
    return render_template('admin_analytics.html',
                         enrollment_data=enrollment_data,
                         performance_data=performance_data)

@app.route('/admin/assign_faculty/<int:request_id>', methods=['POST'])
@login_required
@role_required('admin')
def assign_faculty(request_id):
    instructor_id = request.form.get('instructor_id')
    if not instructor_id:
        flash('Please select an instructor to assign.', 'warning')
        return redirect(url_for('admin_dashboard'))

    conn = get_db()
    request_row = conn.execute('SELECT * FROM course_requests WHERE id = ?', (request_id,)).fetchone()
    if not request_row:
        conn.close()
        flash('Course request not found.', 'danger')
        return redirect(url_for('admin_dashboard'))

    # Create a new course and assign instructor
    conn.execute('''INSERT INTO courses (title, description, instructor_id, status)
                    VALUES (?, ?, ?, 'approved')''',
                 (request_row['title'], request_row['description'], instructor_id))

    conn.execute('UPDATE course_requests SET status = "assigned" WHERE id = ?', (request_id,))
    conn.commit()
    conn.close()

    flash('Faculty assigned and course published successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

# ========== INSTRUCTOR MODULE ==========

@app.route('/instructor/dashboard')
@login_required
@role_required('instructor')
def instructor_dashboard():
    conn = get_db()
    
    instructor_id = session['user_id']
    
    # Get instructor's courses
    courses = conn.execute('SELECT * FROM courses WHERE instructor_id = ? ORDER BY created_at DESC',
                          (instructor_id,)).fetchall()
    
    # Get statistics
    total_courses = len(courses)
    approved_courses = len([c for c in courses if c['status'] == 'approved'])
    
    total_students = conn.execute('''
        SELECT COUNT(DISTINCT e.student_id) as count
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        WHERE c.instructor_id = ?
    ''', (instructor_id,)).fetchone()['count']
    
    conn.close()
    
    return render_template('instructor_dashboard.html',
                         courses=courses,
                         total_courses=total_courses,
                         approved_courses=approved_courses,
                         total_students=total_students)

@app.route('/instructor/create_course', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def create_course():
    conn = get_db()
    categories = conn.execute('SELECT * FROM course_categories ORDER BY name').fetchall()
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        instructor_id = session['user_id']
        selected_categories = request.form.getlist('categories')
        
        cursor = conn.execute('INSERT INTO courses (title, description, instructor_id) VALUES (?, ?, ?)',
                    (title, description, instructor_id))
        course_id = cursor.lastrowid
        
        # Add categories
        for category_id in selected_categories:
            try:
                conn.execute('INSERT INTO course_category_mapping (course_id, category_id) VALUES (?, ?)',
                           (course_id, category_id))
            except sqlite3.IntegrityError:
                pass
        
        conn.commit()
        conn.close()
        
        flash('Course created successfully! Waiting for admin approval.', 'success')
        return redirect(url_for('instructor_dashboard'))
    
    conn.close()
    return render_template('create_course.html', categories=categories)

@app.route('/instructor/course/<int:course_id>')
@login_required
@role_required('instructor')
def instructor_course_details(course_id):
    conn = get_db()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ? AND instructor_id = ?',
                         (course_id, session['user_id'])).fetchone()
    
    if not course:
        flash('Course not found or access denied.', 'danger')
        return redirect(url_for('instructor_dashboard'))
    
    materials = conn.execute('SELECT * FROM course_materials WHERE course_id = ? ORDER BY created_at DESC',
                            (course_id,)).fetchall()
    
    assessments = conn.execute('SELECT * FROM assessments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()
    
    assignments = conn.execute('SELECT * FROM assignments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()
    
    students = conn.execute('''
        SELECT u.*, e.enrolled_at
        FROM users u
        JOIN enrollments e ON u.id = e.student_id
        WHERE e.course_id = ?
        ORDER BY e.enrolled_at DESC
    ''', (course_id,)).fetchall()

    calendar_events = conn.execute('''
        SELECT * FROM academic_calendar
        WHERE course_id = ?
        ORDER BY start_date ASC
    ''', (course_id,)).fetchall()

    attendance_sessions = conn.execute('''
        SELECT * FROM attendance_sessions
        WHERE course_id = ?
        ORDER BY session_date DESC
    ''', (course_id,)).fetchall()

    attendance_records = conn.execute('''
        SELECT ar.*, u.full_name
        FROM attendance_records ar
        JOIN users u ON ar.student_id = u.id
        WHERE ar.session_id IN (
            SELECT id FROM attendance_sessions WHERE course_id = ?
        )
    ''', (course_id,)).fetchall()

    attendance_map = {}
    for record in attendance_records:
        attendance_map.setdefault(record['session_id'], {})[record['student_id']] = record['status']
    
    conn.close()
    
    return render_template('instructor_course_details.html',
                         course=course,
                         materials=materials,
                         assessments=assessments,
                         assignments=assignments,
                         students=students,
                         calendar_events=calendar_events,
                         attendance_sessions=attendance_sessions,
                         attendance_map=attendance_map)

@app.route('/instructor/add_material/<int:course_id>', methods=['POST'])
@login_required
@role_required('instructor')
def add_material(course_id):
    title = request.form['title']
    content = request.form['content']
    material_type = request.form['material_type']
    
    conn = get_db()
    conn.execute('''INSERT INTO course_materials (course_id, title, content, material_type)
                   VALUES (?, ?, ?, ?)''',
                (course_id, title, content, material_type))
    conn.commit()
    conn.close()
    
    flash('Material added successfully!', 'success')
    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/course/<int:course_id>/calendar/add', methods=['POST'])
@login_required
@role_required('instructor')
def add_calendar_event(course_id):
    title = request.form['title']
    description = request.form.get('description', '')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')

    conn = get_db()
    conn.execute('''
        INSERT INTO academic_calendar (course_id, title, description, start_date, end_date)
        VALUES (?, ?, ?, ?, ?)''',
        (course_id, title, description, start_date, end_date))
    conn.commit()
    conn.close()

    flash('Academic calendar event added.', 'success')
    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/course/<int:course_id>/calendar/generate', methods=['POST'])
@login_required
@role_required('instructor')
def generate_calendar_events(course_id):
    title_prefix = request.form.get('title_prefix', 'Class Session').strip() or 'Class Session'
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    frequency = request.form.get('frequency', 'weekly')

    if not start_date or not end_date:
        flash('Start date and end date are required.', 'warning')
        return redirect(url_for('instructor_course_details', course_id=course_id))

    conn = get_db()

    try:
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        if start > end:
            raise ValueError('Start date must be before end date.')

        delta_days = 7 if frequency == 'weekly' else 1
        current = start
        count = 0

        while current <= end:
            conn.execute('''
                INSERT INTO academic_calendar (course_id, title, description, start_date, end_date)
                VALUES (?, ?, ?, ?, ?)''',
                (course_id, f"{title_prefix} - {current.strftime('%b %d')}", '', current.isoformat(), current.isoformat()))
            count += 1
            current = current + timedelta(days=delta_days)

        conn.commit()
        flash(f'{count} calendar events generated successfully.', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Error generating events: {str(e)}', 'danger')
    finally:
        conn.close()

    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/course/<int:course_id>/attendance/session/add', methods=['POST'])
@login_required
@role_required('instructor')
def add_attendance_session(course_id):
    session_date = request.form.get('session_date')
    topic = request.form.get('topic', '')

    conn = get_db()
    conn.execute('''
        INSERT INTO attendance_sessions (course_id, session_date, topic)
        VALUES (?, ?, ?)''',
        (course_id, session_date, topic))
    conn.commit()
    conn.close()

    flash('Attendance session created.', 'success')
    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/course/<int:course_id>/attendance/session/generate', methods=['POST'])
@login_required
@role_required('instructor')
def generate_attendance_sessions(course_id):
    topic_prefix = request.form.get('topic_prefix', 'Class').strip() or 'Class'
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    frequency = request.form.get('frequency', 'weekly')

    if not start_date or not end_date:
        flash('Start date and end date are required.', 'warning')
        return redirect(url_for('instructor_course_details', course_id=course_id))

    conn = get_db()

    try:
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        if start > end:
            raise ValueError('Start date must be before end date.')

        delta_days = 7 if frequency == 'weekly' else 1
        current = start
        count = 0

        while current <= end:
            conn.execute('''
                INSERT INTO attendance_sessions (course_id, session_date, topic)
                VALUES (?, ?, ?)''',
                (course_id, current.isoformat(), f"{topic_prefix} - {current.strftime('%b %d')}") )
            count += 1
            current = current + timedelta(days=delta_days)

        conn.commit()
        flash(f'{count} attendance sessions generated successfully.', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Error generating attendance sessions: {str(e)}', 'danger')
    finally:
        conn.close()

    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/course/<int:course_id>/attendance/session/<int:session_id>/mark', methods=['POST'])
@login_required
@role_required('instructor')
def mark_attendance(course_id, session_id):
    conn = get_db()

    students = conn.execute('''
        SELECT u.id
        FROM users u
        JOIN enrollments e ON u.id = e.student_id
        WHERE e.course_id = ? AND u.role = 'student'
    ''', (course_id,)).fetchall()

    for student in students:
        status = request.form.get(f'status_{student["id"]}', 'absent')
        try:
            conn.execute('''
                INSERT INTO attendance_records (session_id, student_id, status)
                VALUES (?, ?, ?)''',
                (session_id, student['id'], status))
        except sqlite3.IntegrityError:
            conn.execute('''
                UPDATE attendance_records
                SET status = ?, marked_at = CURRENT_TIMESTAMP
                WHERE session_id = ? AND student_id = ?''',
                (status, session_id, student['id']))

    conn.commit()
    conn.close()

    flash('Attendance updated.', 'success')
    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/create_assessment/<int:course_id>', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def create_assessment(course_id):
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        total_marks = request.form['total_marks']
        
        conn = get_db()
        cursor = conn.execute('''INSERT INTO assessments (course_id, title, description, total_marks)
                               VALUES (?, ?, ?, ?)''',
                            (course_id, title, description, total_marks))
        assessment_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        flash('Assessment created! Now add questions.', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment_id))
    
    conn = get_db()
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    conn.close()
    
    return render_template('create_assessment.html', course=course)

@app.route('/instructor/add_questions/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def add_questions(assessment_id):
    if request.method == 'POST':
        question_text = request.form['question_text']
        option_a = request.form['option_a']
        option_b = request.form['option_b']
        option_c = request.form['option_c']
        option_d = request.form['option_d']
        correct_answer = request.form['correct_answer']
        marks = request.form['marks']
        
        conn = get_db()
        conn.execute('''INSERT INTO questions 
                       (assessment_id, question_text, option_a, option_b, option_c, option_d, correct_answer, marks)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                    (assessment_id, question_text, option_a, option_b, option_c, option_d, correct_answer, marks))
        conn.commit()
        conn.close()
        
        flash('Question added successfully!', 'success')
        
        if 'add_another' in request.form:
            return redirect(url_for('add_questions', assessment_id=assessment_id))
        else:
            return redirect(url_for('instructor_dashboard'))
    
    conn = get_db()
    assessment = conn.execute('''
        SELECT a.*, c.title as course_title
        FROM assessments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    ''', (assessment_id,)).fetchone()
    
    questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                            (assessment_id,)).fetchall()
    conn.close()
    
    return render_template('add_questions.html', assessment=assessment, questions=questions)

@app.route('/instructor/student_performance/<int:course_id>')
@login_required
@role_required('instructor')
def student_performance(course_id):
    conn = get_db()
    
    # Get all students enrolled in the course with their performance
    performance = conn.execute('''
        SELECT 
            u.id, u.full_name, u.email,
            AVG(CASE WHEN a.course_id = ? THEN r.percentage END) as avg_percentage,
            COUNT(DISTINCT CASE WHEN a.course_id = ? THEN r.assessment_id END) as assessments_taken
        FROM users u
        JOIN enrollments e ON u.id = e.student_id
        LEFT JOIN results r ON u.id = r.student_id
        LEFT JOIN assessments a ON r.assessment_id = a.id
        WHERE e.course_id = ? AND u.role = 'student'
        GROUP BY u.id
        ORDER BY avg_percentage DESC
    ''', (course_id, course_id, course_id)).fetchall()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    
    conn.close()
    
    return render_template('student_performance.html', performance=performance, course=course)

# ========== STUDENT MODULE ==========

@app.route('/student/dashboard')
@login_required
@role_required('student')
def student_dashboard():
    conn = get_db()
    
    student_id = session['user_id']
    search = request.args.get('search', '')
    category_filter = request.args.get('category', '')
    
    # Get enrolled courses
    enrolled_courses = conn.execute('''
        SELECT c.*, e.enrolled_at
        FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        WHERE e.student_id = ? AND c.status = "approved"
        ORDER BY e.enrolled_at DESC
    ''', (student_id,)).fetchall()
    
    # Get available courses with filters
    query = '''
        SELECT c.*, u.full_name as instructor_name,
               COALESCE(AVG(cr.rating), 0) as avg_rating,
               COUNT(DISTINCT e.id) as enrollment_count
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        LEFT JOIN course_reviews cr ON c.id = cr.course_id
        LEFT JOIN enrollments e ON c.id = e.course_id
        WHERE c.status = "approved" 
        AND c.id NOT IN (
            SELECT course_id FROM enrollments WHERE student_id = ?
        )
    '''
    params = [student_id]
    
    if search:
        query += ' AND (c.title LIKE ? OR c.description LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%'])
    
    if category_filter:
        query += ''' AND c.id IN (
            SELECT course_id FROM course_category_mapping WHERE category_id = ?
        )'''
        params.append(category_filter)
    
    query += ' GROUP BY c.id ORDER BY c.created_at DESC'
    
    available_courses = conn.execute(query, params).fetchall()
    
    # Get recent results
    recent_results = conn.execute('''
        SELECT r.*, a.title as assessment_title, c.title as course_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY r.submitted_at DESC
        LIMIT 5
    ''', (student_id,)).fetchall()

    # Course requests and votes
    course_requests = conn.execute('''
        SELECT cr.*, COUNT(crv.id) as votes
        FROM course_requests cr
        LEFT JOIN course_request_votes crv ON cr.id = crv.request_id
        WHERE cr.status = 'pending'
        GROUP BY cr.id
        ORDER BY votes DESC, cr.created_at DESC
    ''').fetchall()

    my_votes = conn.execute('''
        SELECT request_id FROM course_request_votes WHERE student_id = ?
    ''', (student_id,)).fetchall()
    voted_request_ids = {row['request_id'] for row in my_votes}
    
    # Get categories
    categories = conn.execute('SELECT * FROM course_categories ORDER BY name').fetchall()
    
    # Get unread notifications count
    unread_notifications = conn.execute(
        'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0',
        (student_id,)
    ).fetchone()['count']
    
    # Get user badges
    badges = conn.execute('''
        SELECT b.* FROM badges b
        JOIN user_badges ub ON b.id = ub.badge_id
        WHERE ub.user_id = ?
        ORDER BY ub.earned_at DESC
    ''', (student_id,)).fetchall()

    # Get upcoming calendar events from enrolled courses
    calendar_events = conn.execute('''
        SELECT ac.*, c.title as course_title
        FROM academic_calendar ac
        JOIN courses c ON ac.course_id = c.id
        WHERE ac.course_id IN (
            SELECT course_id FROM enrollments WHERE student_id = ?
        )
        AND (ac.start_date >= date('now') OR ac.end_date >= date('now'))
        ORDER BY ac.start_date ASC
        LIMIT 10
    ''', (student_id,)).fetchall()

    # Get recent attendance records
    recent_attendance = conn.execute('''
        SELECT 
            ats.session_date, ats.topic, 
            ar.status,
            c.title as course_title
        FROM attendance_sessions ats
        JOIN courses c ON ats.course_id = c.id
        LEFT JOIN attendance_records ar 
            ON ats.id = ar.session_id AND ar.student_id = ?
        WHERE ats.course_id IN (
            SELECT course_id FROM enrollments WHERE student_id = ?
        )
        ORDER BY ats.session_date DESC
        LIMIT 15
    ''', (student_id, student_id)).fetchall()

    conn.close()
    
    return render_template('student_dashboard.html',
                         enrolled_courses=enrolled_courses,
                         available_courses=available_courses,
                         recent_results=recent_results,
                         course_requests=course_requests,
                         voted_request_ids=voted_request_ids,
                         categories=categories,
                         search=search,
                         category_filter=category_filter,
                         unread_notifications=unread_notifications,
                         badges=badges,
                         calendar_events=calendar_events,
                         recent_attendance=recent_attendance)

@app.route('/student/enroll/<int:course_id>')
@login_required
@role_required('student')
def enroll_course(course_id):
    conn = get_db()
    
    # Check if already enrolled
    existing = conn.execute('SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?',
                           (session['user_id'], course_id)).fetchone()
    
    if existing:
        flash('You are already enrolled in this course.', 'info')
    else:
        conn.execute('INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)',
                    (session['user_id'], course_id))
        
        # Get course info for notification
        course = conn.execute('SELECT title, instructor_id FROM courses WHERE id = ?', (course_id,)).fetchone()
        
        # Notify instructor
        create_notification(
            conn,
            course['instructor_id'],
            'New Student Enrollment',
            f"{session['full_name']} enrolled in your course: {course['title']}",
            f"/instructor/course/{course_id}"
        )
        
        conn.commit()
        flash('Successfully enrolled in the course!', 'success')
        
        # Check and award badges
        check_and_award_badges(session['user_id'])
    
    conn.close()
    return redirect(url_for('student_dashboard'))

@app.route('/student/request_course', methods=['POST'])
@login_required
@role_required('student')
def request_course():
    title = request.form['title'].strip()
    description = request.form.get('description', '').strip()

    if not title:
        flash('Course title is required.', 'warning')
        return redirect(url_for('student_dashboard'))

    conn = get_db()
    # Check if a pending request with the same title exists
    existing = conn.execute('''
        SELECT id FROM course_requests
        WHERE LOWER(title) = LOWER(?) AND status = 'pending'
    ''', (title,)).fetchone()

    if existing:
        request_id = existing['id']
    else:
        cursor = conn.execute('''
            INSERT INTO course_requests (title, description, requested_by)
            VALUES (?, ?, ?)''',
            (title, description, session['user_id']))
        request_id = cursor.lastrowid

    # Add vote/support
    try:
        conn.execute('''
            INSERT INTO course_request_votes (request_id, student_id)
            VALUES (?, ?)''',
            (request_id, session['user_id']))
        conn.commit()
        flash('Course request submitted and supported!', 'success')
    except sqlite3.IntegrityError:
        flash('You have already supported this course request.', 'info')
    finally:
        conn.close()

    return redirect(url_for('student_dashboard'))

@app.route('/student/support_course/<int:request_id>', methods=['POST'])
@login_required
@role_required('student')
def support_course(request_id):
    conn = get_db()
    try:
        conn.execute('''
            INSERT INTO course_request_votes (request_id, student_id)
            VALUES (?, ?)''',
            (request_id, session['user_id']))
        conn.commit()
        flash('Thanks! You supported this course request.', 'success')
    except sqlite3.IntegrityError:
        flash('You have already supported this course request.', 'info')
    finally:
        conn.close()

    return redirect(url_for('student_dashboard'))

@app.route('/student/course/<int:course_id>')
@login_required
@role_required('student')
def student_course_view(course_id):
    conn = get_db()
    
    # Check if student is enrolled
    enrollment = conn.execute('SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?',
                             (session['user_id'], course_id)).fetchone()
    
    if not enrollment:
        flash('You are not enrolled in this course.', 'danger')
        return redirect(url_for('student_dashboard'))
    
    course = conn.execute('''
        SELECT c.*, u.full_name as instructor_name
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.id = ?
    ''', (course_id,)).fetchone()
    
    materials = conn.execute('SELECT * FROM course_materials WHERE course_id = ? ORDER BY created_at DESC',
                            (course_id,)).fetchall()
    
    assessments = conn.execute('SELECT * FROM assessments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()

    calendar_events = conn.execute('''
        SELECT * FROM academic_calendar
        WHERE course_id = ?
        ORDER BY start_date ASC
    ''', (course_id,)).fetchall()

    attendance_summary = conn.execute('''
        SELECT s.id as session_id, s.session_date, s.topic, ar.status
        FROM attendance_sessions s
        LEFT JOIN attendance_records ar
            ON s.id = ar.session_id AND ar.student_id = ?
        WHERE s.course_id = ?
        ORDER BY s.session_date DESC
    ''', (session['user_id'], course_id)).fetchall()
    
    # Get student's results for this course
    results = conn.execute('''
        SELECT r.*, a.title as assessment_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        WHERE r.student_id = ? AND a.course_id = ?
    ''', (session['user_id'], course_id)).fetchall()
    
    conn.close()
    
    return render_template('student_course_view.html',
                         course=course,
                         materials=materials,
                         assessments=assessments,
                         results=results,
                         calendar_events=calendar_events,
                         attendance_summary=attendance_summary)

@app.route('/student/take_assessment/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
@role_required('student')
def take_assessment(assessment_id):
    conn = get_db()
    
    if request.method == 'POST':
        # Calculate score
        questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                                (assessment_id,)).fetchall()
        
        score = 0
        total_marks = 0
        
        for question in questions:
            total_marks += question['marks']
            user_answer = request.form.get(f'question_{question["id"]}')
            if user_answer == question['correct_answer']:
                score += question['marks']
        
        percentage = (score / total_marks * 100) if total_marks > 0 else 0
        
        # Save result
        conn.execute('''INSERT INTO results (student_id, assessment_id, score, total_marks, percentage)
                       VALUES (?, ?, ?, ?, ?)''',
                    (session['user_id'], assessment_id, score, total_marks, percentage))
        conn.commit()
        conn.close()
        
        flash(f'Assessment submitted! You scored {score}/{total_marks} ({percentage:.2f}%)', 'success')
        return redirect(url_for('student_dashboard'))
    
    # Check if already taken
    existing_result = conn.execute('SELECT * FROM results WHERE student_id = ? AND assessment_id = ?',
                                  (session['user_id'], assessment_id)).fetchone()
    
    if existing_result:
        flash('You have already taken this assessment.', 'info')
        conn.close()
        return redirect(url_for('student_dashboard'))
    
    assessment = conn.execute('''
        SELECT a.*, c.title as course_title
        FROM assessments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    ''', (assessment_id,)).fetchone()
    
    questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                            (assessment_id,)).fetchall()
    
    conn.close()
    
    return render_template('take_assessment.html', assessment=assessment, questions=questions)

@app.route('/student/my_performance')
@login_required
@role_required('student')
def my_performance():
    conn = get_db()
    
    results = conn.execute('''
        SELECT r.*, a.title as assessment_title, c.title as course_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY r.submitted_at DESC
    ''', (session['user_id'],)).fetchall()
    
    # Calculate overall statistics
    if results:
        avg_percentage = sum(r['percentage'] for r in results) / len(results)
        total_assessments = len(results)
    else:
        avg_percentage = 0
        total_assessments = 0
    
    conn.close()
    
    return render_template('my_performance.html',
                         results=results,
                         avg_percentage=avg_percentage,
                         total_assessments=total_assessments)

# ========== ANNOUNCEMENTS ==========

@app.route('/announcements')
@login_required
def announcements():
    conn = get_db()
    
    if session['role'] == 'student':
        # Get global announcements and course-specific ones
        announcements = conn.execute('''
            SELECT a.*, u.full_name as created_by_name, c.title as course_title
            FROM announcements a
            JOIN users u ON a.created_by = u.id
            LEFT JOIN courses c ON a.course_id = c.id
            WHERE a.is_global = 1 OR a.course_id IN (
                SELECT course_id FROM enrollments WHERE student_id = ?
            )
            ORDER BY a.created_at DESC
        ''', (session['user_id'],)).fetchall()
    else:
        # Instructors and admins see all announcements
        announcements = conn.execute('''
            SELECT a.*, u.full_name as created_by_name, c.title as course_title
            FROM announcements a
            JOIN users u ON a.created_by = u.id
            LEFT JOIN courses c ON a.course_id = c.id
            ORDER BY a.created_at DESC
        ''').fetchall()
    
    conn.close()
    return render_template('announcements.html', announcements=announcements)

@app.route('/announcement/create', methods=['POST'])
@login_required
def create_announcement():
    title = request.form['title']
    content = request.form['content']
    course_id = request.form.get('course_id')
    is_global = 1 if request.form.get('is_global') else 0
    
    conn = get_db()
    try:
        conn.execute('''INSERT INTO announcements (title, content, course_id, is_global, created_by)
                        VALUES (?, ?, ?, ?, ?)''',
                    (title, content, course_id if course_id else None, is_global, session['user_id']))
        
        # Create notifications for relevant users
        if is_global:
            students = conn.execute('SELECT id FROM users WHERE role = "student"').fetchall()
            for student in students:
                create_notification(conn, student['id'], f'New Announcement: {title}', content[:100], '/announcements')
        elif course_id:
            students = conn.execute('SELECT student_id FROM enrollments WHERE course_id = ?', (course_id,)).fetchall()
            for student in students:
                create_notification(conn, student['student_id'], f'Course Announcement: {title}', content[:100], '/announcements')
        
        conn.commit()
        flash('Announcement created successfully!', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Error creating announcement: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('announcements'))

# ========== DISCUSSION FORUMS ==========

@app.route('/course/<int:course_id>/forum')
@login_required
def course_forum(course_id):
    conn = get_db()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    
    threads = conn.execute('''
        SELECT ft.*, u.full_name as author_name, COUNT(fr.id) as reply_count
        FROM forum_threads ft
        JOIN users u ON ft.created_by = u.id
        LEFT JOIN forum_replies fr ON ft.id = fr.thread_id
        WHERE ft.course_id = ?
        GROUP BY ft.id
        ORDER BY ft.created_at DESC
    ''', (course_id,)).fetchall()
    
    conn.close()
    return render_template('course_forum.html', course=course, threads=threads)

@app.route('/course/<int:course_id>/forum/thread/create', methods=['POST'])
@login_required
def create_forum_thread(course_id):
    title = request.form['title']
    content = request.form['content']
    
    conn = get_db()
    conn.execute('''INSERT INTO forum_threads (course_id, title, content, created_by)
                    VALUES (?, ?, ?, ?)''',
                (course_id, title, content, session['user_id']))
    conn.commit()
    conn.close()
    
    flash('Discussion thread created!', 'success')
    return redirect(url_for('course_forum', course_id=course_id))

@app.route('/forum/thread/<int:thread_id>')
@login_required
def forum_thread(thread_id):
    conn = get_db()
    
    thread = conn.execute('''
        SELECT ft.*, u.full_name as author_name, c.id as course_id, c.title as course_title
        FROM forum_threads ft
        JOIN users u ON ft.created_by = u.id
        JOIN courses c ON ft.course_id = c.id
        WHERE ft.id = ?
    ''', (thread_id,)).fetchone()
    
    replies = conn.execute('''
        SELECT fr.*, u.full_name as author_name
        FROM forum_replies fr
        JOIN users u ON fr.created_by = u.id
        WHERE fr.thread_id = ?
        ORDER BY fr.created_at ASC
    ''', (thread_id,)).fetchall()
    
    conn.close()
    return render_template('forum_thread.html', thread=thread, replies=replies)

@app.route('/forum/thread/<int:thread_id>/reply', methods=['POST'])
@login_required
def reply_forum_thread(thread_id):
    content = request.form['content']
    
    conn = get_db()
    conn.execute('''INSERT INTO forum_replies (thread_id, content, created_by)
                    VALUES (?, ?, ?)''',
                (thread_id, content, session['user_id']))
    conn.commit()
    conn.close()
    
    flash('Reply posted!', 'success')
    return redirect(url_for('forum_thread', thread_id=thread_id))

# ========== NOTIFICATIONS ==========

@app.route('/notifications')
@login_required
def notifications():
    conn = get_db()
    
    notifications = conn.execute('''
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 50
    ''', (session['user_id'],)).fetchall()
    
    # Mark all as read
    conn.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (session['user_id'],))
    conn.commit()
    conn.close()
    
    return render_template('notifications.html', notifications=notifications)

# ========== COURSE RATINGS ==========

@app.route('/course/<int:course_id>/rate', methods=['POST'])
@login_required
@role_required('student')
def rate_course(course_id):
    rating = int(request.form['rating'])
    review = request.form.get('review', '')
    
    conn = get_db()
    try:
        conn.execute('''INSERT INTO course_reviews (course_id, student_id, rating, review)
                        VALUES (?, ?, ?, ?)''',
                    (course_id, session['user_id'], rating, review))
        conn.commit()
        flash('Thank you for your review!', 'success')
    except sqlite3.IntegrityError:
        conn.execute('''UPDATE course_reviews SET rating = ?, review = ?
                        WHERE course_id = ? AND student_id = ?''',
                    (rating, review, course_id, session['user_id']))
        conn.commit()
        flash('Your review has been updated!', 'success')
    finally:
        conn.close()
    
    return redirect(url_for('student_course_view', course_id=course_id))

# ========== CERTIFICATES ==========

@app.route('/student/certificate/<int:course_id>')
@login_required
@role_required('student')
def view_certificate(course_id):
    import random
    import string
    
    conn = get_db()
    
    # Check if student completed the course (has taken at least one assessment)
    assessments_taken = conn.execute('''
        SELECT COUNT(*) as count FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        WHERE r.student_id = ? AND a.course_id = ?
    ''', (session['user_id'], course_id)).fetchone()['count']
    
    if assessments_taken == 0:
        flash('Complete at least one assessment to earn a certificate.', 'warning')
        conn.close()
        return redirect(url_for('student_dashboard'))
    
    # Check if certificate already exists
    certificate = conn.execute('''
        SELECT * FROM certificates
        WHERE student_id = ? AND course_id = ?
    ''', (session['user_id'], course_id)).fetchone()
    
    if not certificate:
        # Generate certificate code
        cert_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
        conn.execute('''INSERT INTO certificates (student_id, course_id, certificate_code)
                        VALUES (?, ?, ?)''',
                    (session['user_id'], course_id, cert_code))
        conn.commit()
        certificate = conn.execute('''
            SELECT * FROM certificates
            WHERE student_id = ? AND course_id = ?
        ''', (session['user_id'], course_id)).fetchone()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    conn.close()
    
    return render_template('certificate.html', certificate=certificate, course=course)

# ========== MESSAGING ==========

@app.route('/messages')
@login_required
def messages():
    conn = get_db()
    
    inbox = conn.execute('''
        SELECT m.*, u.full_name as sender_name
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.receiver_id = ?
        ORDER BY m.sent_at DESC
    ''', (session['user_id'],)).fetchall()
    
    sent = conn.execute('''
        SELECT m.*, u.full_name as receiver_name
        FROM messages m
        JOIN users u ON m.receiver_id = u.id
        WHERE m.sender_id = ?
        ORDER BY m.sent_at DESC
    ''', (session['user_id'],)).fetchall()
    
    # Get all users for composing
    users = conn.execute('''
        SELECT id, full_name, email, role
        FROM users
        WHERE id != ? AND status = 'active'
        ORDER BY full_name
    ''', (session['user_id'],)).fetchall()
    
    conn.close()
    return render_template('messages.html', inbox=inbox, sent=sent, users=users)

@app.route('/messages/send', methods=['POST'])
@login_required
def send_message():
    receiver_id = request.form['receiver_id']
    subject = request.form['subject']
    message = request.form['message']
    
    conn = get_db()
    try:
        conn.execute('''INSERT INTO messages (sender_id, receiver_id, subject, message)
                        VALUES (?, ?, ?, ?)''',
                    (session['user_id'], receiver_id, subject, message))
        
        # Create notification using same connection
        create_notification(conn, int(receiver_id), f'New Message: {subject}', message[:100], '/messages')
        
        conn.commit()
        flash('Message sent successfully!', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Error sending message: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('messages'))

@app.route('/messages/read/<int:message_id>')
@login_required
def read_message(message_id):
    conn = get_db()
    conn.execute('UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?',
                (message_id, session['user_id']))
    conn.commit()
    conn.close()
    return redirect(url_for('messages'))

# ========== PROFILE ==========

@app.route('/profile')
@login_required
def profile():
    conn = get_db()
    
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    profile = conn.execute('SELECT * FROM user_profiles WHERE user_id = ?', (session['user_id'],)).fetchone()
    
    badges = conn.execute('''
        SELECT b.* FROM badges b
        JOIN user_badges ub ON b.id = ub.badge_id
        WHERE ub.user_id = ?
        ORDER BY ub.earned_at DESC
    ''', (session['user_id'],)).fetchall()
    
    conn.close()
    return render_template('profile.html', user=user, profile=profile, badges=badges)

@app.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    bio = request.form.get('bio', '')
    phone = request.form.get('phone', '')
    address = request.form.get('address', '')
    
    conn = get_db()
    
    # Check if profile exists
    existing = conn.execute('SELECT * FROM user_profiles WHERE user_id = ?', (session['user_id'],)).fetchone()
    
    if existing:
        conn.execute('''UPDATE user_profiles SET bio = ?, phone = ?, address = ?
                        WHERE user_id = ?''',
                    (bio, phone, address, session['user_id']))
    else:
        conn.execute('''INSERT INTO user_profiles (user_id, bio, phone, address)
                        VALUES (?, ?, ?, ?)''',
                    (session['user_id'], bio, phone, address))
    
    conn.commit()
    conn.close()
    
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('profile'))

# ========== PROGRESS TRACKING ==========

@app.route('/student/course/<int:course_id>/progress')
@login_required
@role_required('student')
def course_progress(course_id):
    conn = get_db()
    
    materials = conn.execute('''
        SELECT cm.*, 
               CASE WHEN sp.completed = 1 THEN 1 ELSE 0 END as is_completed
        FROM course_materials cm
        LEFT JOIN student_progress sp ON cm.id = sp.material_id 
            AND sp.student_id = ? AND sp.course_id = ?
        WHERE cm.course_id = ?
        ORDER BY cm.created_at ASC
    ''', (session['user_id'], course_id, course_id)).fetchall()
    
    total_materials = len(materials)
    completed_materials = sum(1 for m in materials if m['is_completed'])
    progress_percentage = (completed_materials / total_materials * 100) if total_materials > 0 else 0
    
    conn.close()
    return render_template('course_progress.html', 
                         materials=materials, 
                         progress_percentage=progress_percentage,
                         course_id=course_id)

@app.route('/student/material/<int:material_id>/complete', methods=['POST'])
@login_required
@role_required('student')
def complete_material(material_id):
    course_id = request.form.get('course_id')
    
    conn = get_db()
    try:
        conn.execute('''INSERT INTO student_progress (student_id, course_id, material_id, completed, completed_at)
                        VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)''',
                    (session['user_id'], course_id, material_id))
    except sqlite3.IntegrityError:
        conn.execute('''UPDATE student_progress 
                        SET completed = 1, completed_at = CURRENT_TIMESTAMP
                        WHERE student_id = ? AND course_id = ? AND material_id = ?''',
                    (session['user_id'], course_id, material_id))
    
    conn.commit()
    conn.close()
    
    return redirect(url_for('student_course_view', course_id=course_id))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)