# 🚀 Quick Start Guide - Online LMS

## Quick Installation & Running

### Method 1: Using the Run Script (Recommended)
```bash
cd lms_project
./run.sh
```

### Method 2: Manual Start
```bash
cd lms_project
python3 app.py
```

## Access the Application

1. Open your web browser
2. Navigate to: **http://localhost:5000**

## First Time Setup

### 1. Login as Admin
- Username: `admin`
- Password: `admin123`

### 2. Create Test Users

#### Create an Instructor:
1. Logout from admin
2. Click "Register here"
3. Fill in the form:
   - Full Name: John Instructor
   - Username: instructor1
   - Email: instructor@lms.com
   - Password: test123
   - Register as: **Instructor**
4. Click Register

#### Create a Student:
1. Logout
2. Click "Register here"
3. Fill in the form:
   - Full Name: Jane Student
   - Username: student1
   - Email: student@lms.com
   - Password: test123
   - Register as: **Student**
4. Click Register

## Testing the System

### As Instructor:
1. Login as `instructor1` / `test123`
2. Click "Create New Course"
3. Fill in course details
4. Submit (course will be pending approval)

### As Admin:
1. Login as `admin` / `admin123`
2. Go to Dashboard
3. See pending courses
4. Click "Approve" on the course

### As Instructor (Continue):
1. Login back as instructor
2. Click "View" on your approved course
3. Add learning materials
4. Create an assessment
5. Add questions to the assessment

### As Student:
1. Login as `student1` / `test123`
2. See available courses
3. Click "Enroll Now"
4. Click "View Course"
5. Access materials
6. Take assessments
7. View your performance

## Common Tasks

### Adding Course Materials:
1. Go to course details (Instructor)
2. Click "Materials" tab
3. Fill in title, type, and content
4. Click "Add Material"

### Creating Assessments:
1. Go to course details (Instructor)
2. Click "Assessments" tab
3. Click "Create New Assessment"
4. Fill in details
5. Add questions with options and correct answers

### Viewing Performance:
- **Instructors:** Course Details → Students tab → View performance
- **Students:** My Performance menu

## Troubleshooting

### Server won't start?
```bash
# Check Python version (should be 3.8+)
python3 --version

# Install Flask if needed
pip3 install flask
```

### Can't access http://localhost:5000?
- Make sure server is running
- Try http://127.0.0.1:5000
- Check firewall settings

### Database errors?
```bash
# Delete and recreate database
rm data/lms.db
# Restart the application
python3 app.py
```

## Default Port

The application runs on **port 5000** by default.

To change the port, edit `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=8080)  # Change 5000 to 8080
```

## Stopping the Server

Press `Ctrl + C` in the terminal where the server is running.

## Notes

- The database is created automatically on first run
- All data is stored in `data/lms.db`
- The admin account is created automatically
- Passwords are hashed for security

## Getting Help

If you encounter any issues:
1. Check the terminal for error messages
2. Review the README.md file
3. Verify all dependencies are installed
4. Ensure Python 3.8+ is being used

---

**Happy Learning! 📚**
