#!/bin/bash

echo "=========================================="
echo "  Online Learning Management System (LMS)"
echo "  Team 1 - Academic Project"
echo "=========================================="
echo ""
echo "Starting LMS Server..."
echo ""
echo "Default Admin Credentials:"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo "Server will be available at: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo "=========================================="
echo ""

cd "$(dirname "$0")"
python3 app.py
